<?php
// config/vault.php
// Ce fichier contient les identifiants de connexion à la base de données
// Il ne doit PAS être versionné dans Git (.gitignore)

return [
    'database' => [
        'host' => '52.143.152.159',
        'port' => '3306',
        'dbname' => 'LeBonPlan',
        'username' => 'CESIdistant',
        'password' => 'Password1234!',
        'charset' => 'utf8mb4'
    ]
];

?>